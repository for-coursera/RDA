#  PROGRAMMING ASSIGNMENT 1: AIR POLLUTION

complete <- function(directory, id = 1:332) {
  # init vars
  final_table <- data.frame(id=numeric(), nobs=numeric())
  j <- 0
  # get the directory
  active_dir <- paste(getwd(), directory, sep = "/")
  # add leading zeroes 
  idf <- formatC(id, width = 3, format = "d", flag = "0")
  # read the files
  for (i in idf) {
    j <- j + 1
    active_num <- paste(active_dir, i, sep = "/")
    active_fil <- paste(active_num, ".csv", sep = "")
    active_csv <- read.csv(active_fil, header=T, stringsAsFactors=FALSE)
    # count the complete observations
    nobs <- nrow(na.omit(active_csv))
    # combine data
    final_table[j,] <- c(as.integer(i), nobs)
  }
  final_table
}