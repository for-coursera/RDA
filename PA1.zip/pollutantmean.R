#  PROGRAMMING ASSIGNMENT 1: AIR POLLUTION

pollutantmean <- function(directory, pollutant, id = 1:332) {
  # init vars
  final_table <- data.frame(Date=as.Date(character()), sulfate=numeric(), nitrate=numeric(), ID=numeric())
  # get the directory
  active_dir <- paste(getwd(), directory, sep = "/")
  # add leading zeroes 
  idf <- formatC(id, width = 3, format = "d", flag = "0")
  # read the files
  for (i in idf) {
    active_num <- paste(active_dir, i, sep = "/")
    active_fil <- paste(active_num, ".csv", sep = "")
    active_csv <- read.csv(active_fil, header=T, stringsAsFactors=FALSE)
    # combine data
    final_table <- rbind(final_table, active_csv)
  }
  if (pollutant=="sulfate") {
    rez <- mean(as.numeric(na.omit(final_table[,2])))
  } else {
    rez <- mean(as.numeric(na.omit(final_table[,3])))
  }
  rez
}