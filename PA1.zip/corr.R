corr <- function (directory, threshold = 0) {
  # init vars
  k <- 0
  selected_csv <- list()
  rez <- c()
  # get files
  filenames <- list.files(paste(getwd(), directory, sep = "/"), pattern="*.csv", full.names=TRUE)
  # read files
  for (i in filenames) {
    active_csv <- read.csv(i, h=T)
    nobs <- nrow(na.omit(active_csv))
    # select tables read from files
    if (nobs > threshold) {
      # store those tables
      selected_csv[[i]] <- as.data.frame(active_csv)
    }
  }
  for (j in selected_csv) {
    k <- k+1
    tab <- na.omit(as.data.frame(j))
    rez[k] <- cor(as.numeric(tab$sulfate), as.numeric(tab$nitrate))
  }
  rez
}