## Put comments here that give an overall description of what your
## functions do

## Write a short comment describing this function

# The function 'makeCacheMatrix' produces a list containing functions to
#   1. set the value of the matrix
#   2. get the value of the matrix
#   3. set the value of the inversed matrix
#   4. get the value of the inversed matrix
# The link to the environment in which these functions operate is also provided

makeCacheMatrix <- function(x = matrix()) {
  # The inversed matrix will be stored here
  i <- NULL
  # Define the function to store the initial matrix
  set <- function(initial_matrix) {
    # `<<-` is used to store data in the parent env (which is actually our cache env)
    x <<- initial_matrix
    # Since we've just stored a a new matrix, its inversed must be zeroed
    i <<- NULL
  }
  # Define the function to get the initial matrix
  get <- function() {
    x
  }
  # Define the function to store the inversed matrix
  setinv <- function(solved_matrix) {
    i <<- solved_matrix
  }
  # Define the function to get the inversed matrix
  getinv <- function() {
    i
  }
  # Return the list contating of the functions described above
  list(set = set, get = get, setinv = setinv, getinv = getinv)
}


## Write a short comment describing this function

# The function 'cacheSolve' takes the output of the function 
# 'makeCacheMatrix' (which links the functions described above 
# to the certain environment containing the initial matrix) 
# and calculates the inverse of the initially provided matrix. 
# However, it first checks to see if the inversed matrix has 
# already been calculated. If so, it gets this inversed matrix 
# from the cache and skips the computation. Otherwise, it 
# calculates the inversed matrix and sets its value in the 
# cache via the setinv function (see above).
cacheSolve <- function(x, ...) {
  # Check if the inversed matrix is already present in cache
  i <- x$getinv()
  if(!is.null(i)) {
    # If so (its value is not NULL), inform the user and return the 
    # result (thus, exit the function)
    message("Using cached data…")
    return(i)
  }
  # If the function is not exited (there wasn't the inverse matrix 
  # in the cache), get the initial matrix from the environment,
  # calculate the inverse matrix, put it in the cache and return 
  # its value (consequently exitting the function)
  mat <- x$get()
  i <- solve(mat, ...)
  x$setinv(i)
  i        
}
