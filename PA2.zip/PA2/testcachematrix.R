# Generate the matrix, and the inverse of the matrix.
size <- 1000
mymatrix <- matrix(rnorm(size^2), nrow=size, ncol=size)
# Solve the matrix 
mymatrix.inverse <- solve(mymatrix)
# Create a list of functions to set/get the matrix and to set/get its inverse to/from the environment
mymatrix.list   <- makeCacheMatrix(mymatrix)
# Pass the list to `cacheSolve` function to actually calculate the inversed matrix 
# (this should take long, since it's the first go)
mymatrix.solved.1 <- cacheSolve(mymatrix.list)
print("Done!")
# Do it once again to ensure the cache is used 
# (this should be lightning fast)
mymatrix.solved.2 <- cacheSolve(mymatrix.list)
print("Done from cache!")
# Check if all solved matrices are identical (should return TRUE)
if (identical(mymatrix.inverse, mymatrix.solved.1) & identical(mymatrix.inverse, mymatrix.solved.2)) {
  print("Check passed!")
} else {
  print("Check failed!")
}
