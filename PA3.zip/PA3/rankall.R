rankallnew <- function(outcome, num = "best") { 
	data <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
	# Check that the entered outcome is valid 
	outcome_vec <- c("heart attack", "heart failure", "pneumonia")
	states_vec <- sort(unique(data$State))
	if (!is.element(outcome,outcome_vec)) {
		stop("invalid outcome")
		}
	# Adjust the initial data
	# introduce NAs where needed
	data[data=="Not Available"] <- NA
	# Return hospital name in that state with the given rank of 30-day death rate 
	# define the vector of corresponding columns
	reason_vec <- c(11, 17, 23)
	# select the corresponding column according to the provided outcome
	reason <- reason_vec[which(outcome_vec == outcome)]
	# delete NAs for that particular reason (i.e., in that particular column)
	data <- data[!(is.na(data[,reason])),]
	# split the data by states
	sp <- split(data, data$State)
	# for each state sort the data by reason (lowest to highest) and then by alphabet 
	# (`_a` stands for 'list with all data')
	lst_a <- lapply(sp, function(d) { d[with(d, order(as.numeric(d[, reason]), d[,2])), ] } )
	# now, create a list with only columns of interest
	# (`_c` stands for 'list with only selected columns')
	lst_c <- lapply(lst_a, function(d) d[, c(2, 7, reason)])
	# For each state, find the hospital of the given rank
	# define function `showrow` which takes `num` argument and returns a function 
	# to select a corresponding row accross all states
	# more solutions can be found here: 
	# https://stackoverflow.com/questions/28637702/avoiding-if-then-else-structure-in-r
	showrow <- function(row) {
    	switch(class(row),
    		# if `num` is a number
        	numeric = function(d) {
            	d[row,]
	        },
	        # if `num` is a sequence of characters
    	    character = switch(row,
        	    best = function(d){
            	    head(d,1)
	            },
    	        worst = function(d){
        	        tail(d,1)
            	},
	            {
    	            stop("invalid rank")
        	    }),
        	# if `num` is none of the above
	        {
    	        stop("invalid rank")
        	}
	    )
	}
	# using `showrow` select a corresponding row and corresponding colimns
	# (`rez_l` sands for 'rezulting list')
	rez_l <- lapply(lst_c, function(df) { showrow(num)(df)[,c(1,2)] } )
	# unlist the resulting list and save it as a data frame
	rez <- data.frame(matrix(unlist(rez_l), nrow=length(states_vec), byrow=T))
	# set column names
	colnames(rez) <- c("hospital","state")
	# set row names
	rownames(rez) <- states_vec
	# Return a data frame with the hospital names and the (abbreviated) state name 
	return(rez)
} 
