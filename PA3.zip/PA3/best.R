best <- function(state, outcome) { 
	# Read outcome data
	data <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
	# Check that state and outcome are valid 
	outcome_vec <- c("heart attack", "heart failure", "pneumonia")
	states_vec <- unique(data$State)
	if (!is.element(outcome,outcome_vec)) {
		stop("invalid outcome")
		}
	if (!is.element(state, states_vec)) {
		stop("invalid state")
		}
	# Adjust the initial data
	# introduce NAs where needed
	data[data=="Not Available"] <- NA
	# select the state in question
	data <- subset(data, data$State == state)
	# Return hospital name in that state with lowest 30-day death rate 
	# define the vector of corresponding columns
	reason_vec <- c(11, 17, 23)
	# select the corresponding column according to the provided outcome
	reason <- reason_vec[which(outcome_vec == outcome)]
	# order the data by the corresponding reason of death and by hospitals' names 
	# (`order` creates a vector of positions, which is later applied to the data by `with`)
	result <- data[with(data, order(as.numeric(data[,reason]), data[,2])), ]
	# return the first in resulting hospital
	return(result[1,2])
} 

# rprog-011
# nvKApTbNcA