rankall <- function(outcome, num = "best") { 
	data <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
	# Check that the entered outcome is valid 
	outcome_vec <- c("heart attack", "heart failure", "pneumonia")
	states_vec <- sort(unique(data$State))
	if (!is.element(outcome,outcome_vec)) {
		stop("invalid outcome")
		}
	# Adjust the initial data
	# introduce NAs where needed
	data[data=="Not Available"] <- NA
	# Return hospital name in that state with the given rank of 30-day death rate 
	# define the vector of corresponding columns
	reason_vec <- c(11, 17, 23)
	# select the corresponding column according to the provided outcome
	reason <- reason_vec[which(outcome_vec == outcome)]
	# delete NAs for that particular reason (i.e., in that particular column)
	data <- data[!(is.na(data[,reason])),]
	# split the data by states
	sp <- split(data, data$State)
	# for each state sort the data by reason (lowest to highest) and then by alphabet 
	# ('_a' for '_all')
	rez_a <- lapply(sp, function(d) { d[with(d, order(as.numeric(d[, reason]), d[,2])), ] } )
	# now, create a list with only columns of interest
	# ('_c' stands for '_columns')
	rez_c <- lapply(rez_a, function(d) d[, c(2, 7, reason)])
	# For each state, find the hospital of the given rank 
	if (class(num) == "numeric") {
		rez_l <- lapply(rez_c, function(d) { d[num, c(1, 2)] } )
		} else {
			if (num == "worst") {
				rez_l <- lapply(rez_c, function(d) { last_row <- nrow(d) ; d[last_row, c(1, 2)] } )
				} else {
					if (num =="best") {
						rez_l <- lapply(rez_c, function(d) { d[1, c(1, 2)] } )
						} else {
							stop("invalid rank")
						}
					}
				}
	# unlist the resulting list and save it a data frame
	rez <- data.frame(matrix(unlist(rez_l), nrow=length(states_vec), byrow=T))
	rez[,2] <- states_vec
	# set column names
	colnames(rez) <- c("hospital","state")
	# set row names
	rownames(rez) <- states_vec
	# Return a data frame with the hospital names and the (abbreviated) state name 
	return(rez)
} 
